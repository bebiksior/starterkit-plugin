const s = "/my-plugin", t = {
  increment: "my-plugin.increment",
  decrement: "my-plugin.decrement"
}, r = (e) => {
  const n = e.storage.get();
  return n ? n.count : 0;
}, o = (e) => {
  const n = r(e);
  e.storage.set({ count: n + 1 });
}, a = (e) => {
  const n = r(e);
  e.storage.set({ count: n - 1 });
}, l = (e) => {
  const n = r(e), c = document.createElement("div");
  c.className = "my-plugin", c.innerHTML = `
    <div class="my-plugin__count">
      <span>Count:</span>
      <span class="my-plugin__value">${n}</span>
    </div>
    <div>
      <button class="c-button" data-command="${t.increment}">Increment</button>
      <button class="c-button" data-command="${t.decrement}">Decrement</button>
    </div>
  `;
  const u = c.querySelector(".my-plugin__value"), i = c.querySelector(`[data-command="${t.increment}"]`), g = c.querySelector(`[data-command="${t.decrement}"]`);
  e.storage.onChange((d) => {
    const m = d;
    if (m) {
      u.innerHTML = `${m.count}`;
      return;
    }
  }), i.addEventListener("click", () => {
    o(e);
  }), g.addEventListener("click", () => {
    a(e);
  }), e.navigation.addPage(s, {
    body: c
  });
}, p = (e) => {
  e.commands.register(t.increment, {
    name: "Increment",
    run: () => o(e)
  }), e.commands.register(t.decrement, {
    name: "Decrement",
    run: () => a(e)
  }), e.commandPalette.register(t.increment), e.commandPalette.register(t.decrement), l(e), e.sidebar.registerItem("My plugin", s, {
    icon: "fas fa-rocket"
  });
};
export {
  p as init
};
